import QtQuick 2.15
import QtQuick.Controls 2.15
import "../theme"

Rectangle {
    id: guideRoot
    color: "#0F1115"
    border.color: theme.surfaceBorder
    border.width: 1
    radius: 8
    clip: true

    Theme { id: theme }

    ListModel {
        id: gestureGuideModel
        ListElement { name: "CALL"; wire: "CALL"; desc: "Thumb & pinky extended"; category: "HaGRID" }
        ListElement { name: "FIST"; wire: "CLOSED_FIST"; desc: "All fingers closed"; category: "Specialized" }
        ListElement { name: "FOUR"; wire: "FOUR_FINGERS"; desc: "4 fingers open, thumb folded"; category: "Specialized" }
        ListElement { name: "GRAB"; wire: "GRABBING"; desc: "Curled grab posture"; category: "Specialized" }
        ListElement { name: "GRIP"; wire: "GRIP"; desc: "Pinch / grip posture"; category: "HaGRID" }
        ListElement { name: "THUMBS UP"; wire: "THUMBS_UP"; desc: "Thumb extended up"; category: "HaGRID" }
        ListElement { name: "PINKY"; wire: "PINKY"; desc: "Pinky finger only open"; category: "Specialized" }
        ListElement { name: "MIDDLE"; wire: "MIDDLE_FINGER"; desc: "Middle finger extended"; category: "Specialized" }
        ListElement { name: "OK"; wire: "OK"; desc: "Thumb & index ring"; category: "HaGRID" }
        ListElement { name: "POINT"; wire: "INDEX_FINGER"; desc: "Index finger only extended"; category: "Specialized" }
        ListElement { name: "INDEX + PINKY"; wire: "INDEX_PINKY"; desc: "Index & pinky extended"; category: "Specialized" }
        ListElement { name: "STOP"; wire: "STOP"; desc: "Full open palm (Authoritative)"; category: "Safety Rule" }
        ListElement { name: "TWO"; wire: "TWO_FINGERS"; desc: "Index & middle extended"; category: "Specialized" }
        ListElement { name: "THREE"; wire: "THREE_FINGERS"; desc: "3 fingers extended"; category: "Specialized" }
    }

    Column {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 12

        Text {
            text: "SUPPORTED PRODUCT GESTURE TAXONOMY (14 CANONICAL)"
            color: theme.textMuted
            font.family: theme.fontFamily
            font.pixelSize: 11
            font.bold: true
            font.letterSpacing: 1.0
        }

        GridView {
            width: parent.width
            height: parent.height - 32
            cellWidth: width / 2
            cellHeight: 65
            model: gestureGuideModel
            clip: true

            delegate: Rectangle {
                width: GridView.view.cellWidth - 8
                height: 58
                color: theme.surfaceDark
                border.color: theme.surfaceBorder
                radius: 6

                Row {
                    anchors.fill: parent
                    anchors.margins: 10
                    spacing: 12

                    Rectangle {
                        width: 36
                        height: 36
                        radius: 18
                        color: "#1E222A"
                        anchors.verticalCenter: parent.verticalCenter

                        Text {
                            text: model.name.substring(0, 2)
                            color: theme.accentInfo
                            font.family: theme.fontFamily
                            font.pixelSize: 11
                            font.bold: true
                            anchors.centerIn: parent
                        }
                    }

                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 2

                        Row {
                            spacing: 8
                            Text {
                                text: model.name
                                color: theme.textPrimary
                                font.family: theme.fontFamily
                                font.pixelSize: 13
                                font.bold: true
                            }
                            Text {
                                text: "(" + model.category + ")"
                                color: theme.textMuted
                                font.family: theme.fontFamily
                                font.pixelSize: 10
                            }
                        }

                        Text {
                            text: "NG1|" + model.wire + "\\n — " + model.desc
                            color: theme.textSecondary
                            font.family: theme.fontFamily
                            font.pixelSize: 10
                            elide: Text.ElideRight
                            width: 200
                        }
                    }
                }
            }
        }
    }
}
