import QtQuick 2.15
import "../theme"

Rectangle {
    id: detailsRoot
    color: "#0F1115"
    border.color: theme.surfaceBorder
    border.width: 1
    radius: 8

    property string canonicalCommand: "NO_COMMAND"
    property real confidence: 0.0
    property string modelUsed: "N/A"
    property string routingStr: "N/A"
    property real fps: 0.0
    property real latencyMs: 0.0

    Theme { id: theme }

    Column {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 12

        Text {
            text: "TECHNICAL ARCHITECTURE DETAILS"
            color: theme.textMuted
            font.family: theme.fontFamily
            font.pixelSize: 11
            font.bold: true
            font.letterSpacing: 1.0
        }

        Rectangle {
            width: parent.width
            height: 1
            color: theme.surfaceBorder
        }

        Grid {
            columns: 2
            columnSpacing: 24
            rowSpacing: 12
            width: parent.width

            Text { text: "Canonical Protocol Name:"; color: theme.textMuted; font.pixelSize: 12; font.family: theme.fontFamily }
            Text { text: detailsRoot.canonicalCommand; color: theme.accentActive; font.pixelSize: 12; font.bold: true; font.family: theme.fontFamily }

            Text { text: "Raw Inference Confidence:"; color: theme.textMuted; font.pixelSize: 12; font.family: theme.fontFamily }
            Text { text: (detailsRoot.confidence * 100).toFixed(1) + "%"; color: theme.textPrimary; font.pixelSize: 12; font.bold: true; font.family: theme.fontFamily }

            Text { text: "Active ML Architecture:"; color: theme.textMuted; font.pixelSize: 12; font.family: theme.fontFamily }
            Text { text: detailsRoot.modelUsed; color: theme.textPrimary; font.pixelSize: 12; font.bold: true; font.family: theme.fontFamily }

            Text { text: "Feature Vector Dimension:"; color: theme.textMuted; font.pixelSize: 12; font.family: theme.fontFamily }
            Text { text: "68-D Normalized Features"; color: theme.textPrimary; font.pixelSize: 12; font.bold: true; font.family: theme.fontFamily }

            Text { text: "Hand Tracking Engine:"; color: theme.textMuted; font.pixelSize: 12; font.family: theme.fontFamily }
            Text { text: "MediaPipe HandLandmarker Tasks API"; color: theme.textPrimary; font.pixelSize: 12; font.bold: true; font.family: theme.fontFamily }

            Text { text: "Wire Transport Protocol:"; color: theme.textMuted; font.pixelSize: 12; font.family: theme.fontFamily }
            Text { text: "NG1|<CMD>\\n (115200 Baud)"; color: theme.textPrimary; font.pixelSize: 12; font.bold: true; font.family: theme.fontFamily }

            Text { text: "Pipeline Latency:"; color: theme.textMuted; font.pixelSize: 12; font.family: theme.fontFamily }
            Text { text: detailsRoot.latencyMs.toFixed(1) + " ms (" + detailsRoot.fps.toFixed(1) + " FPS)"; color: theme.accentInfo; font.pixelSize: 12; font.bold: true; font.family: theme.fontFamily }
        }

        Rectangle {
            width: parent.width
            height: 1
            color: theme.surfaceBorder
        }

        Text {
            text: "Detailed Route Path Log:"
            color: theme.textMuted
            font.pixelSize: 11
            font.bold: true
            font.family: theme.fontFamily
        }

        Text {
            text: detailsRoot.routingStr
            color: theme.textSecondary
            font.pixelSize: 11
            font.family: "Consolas, monospace"
            wrapMode: Text.Wrap
            width: parent.width
        }
    }
}
