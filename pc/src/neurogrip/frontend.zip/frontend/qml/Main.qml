import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import "theme"
import "components"
import "views"

ApplicationWindow {
    id: window
    width: 1280
    height: 800
    minimumWidth: 960
    minimumHeight: 640
    visible: true
    title: "NEUROGRIP — Multimodal Hand Control System"
    color: theme.bgDark

    Theme { id: theme }

    property int activeViewIndex: 0 // 0: Live Monitor, 1: Gesture Guide, 2: Details

    // Shortcut for F11 Fullscreen Toggle
    Shortcut {
        sequence: "F11"
        onActivated: {
            if (window.visibility === Window.FullScreen) {
                window.showNormal();
            } else {
                window.showFullScreen();
            }
        }
    }

    // Ambient Particle Background
    ParticleBackground {}

    // Master Layout
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 14

        // ── Top Header Bar ───────────────────────────────────────────────────
        Rectangle {
            Layout.fillWidth: true
            height: 56
            color: theme.surfaceDark
            border.color: theme.surfaceBorder
            border.width: 1
            radius: 8

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 16
                anchors.rightMargin: 16

                // Brand / Title
                Row {
                    spacing: 12
                    Layout.alignment: Qt.AlignVCenter

                    Rectangle {
                        width: 32
                        height: 32
                        radius: 6
                        color: "#161920"
                        border.color: theme.surfaceBorder
                        anchors.verticalCenter: parent.verticalCenter

                        Text {
                            text: "NG"
                            color: theme.accentActive
                            font.family: theme.fontFamily
                            font.pixelSize: 13
                            font.bold: true
                            anchors.centerIn: parent
                        }
                    }

                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 1

                        Text {
                            text: "NEUROGRIP"
                            color: theme.textPrimary
                            font.family: theme.fontFamily
                            font.pixelSize: 15
                            font.bold: true
                            font.letterSpacing: 2.0
                        }

                        Text {
                            text: "MULTIMODAL HAND CONTROL SYSTEM"
                            color: theme.textMuted
                            font.family: theme.fontFamily
                            font.pixelSize: 8
                            font.bold: true
                            font.letterSpacing: 1.0
                        }
                    }
                }

                Item { Layout.fillWidth: true }

                // Navigation Tabs
                Row {
                    spacing: 6
                    Layout.alignment: Qt.AlignVCenter

                    Button {
                        text: "LIVE MONITOR"
                        onClicked: window.activeViewIndex = 0
                        contentItem: Text {
                            text: parent.text
                            color: window.activeViewIndex === 0 ? theme.accentActive : theme.textMuted
                            font.family: theme.fontFamily
                            font.pixelSize: 10
                            font.bold: true
                        }
                        background: Rectangle {
                            color: window.activeViewIndex === 0 ? "#1E222A" : "transparent"
                            radius: 4
                            implicitWidth: 95
                            implicitHeight: 30
                        }
                    }

                    Button {
                        text: "GESTURE GUIDE"
                        onClicked: window.activeViewIndex = 1
                        contentItem: Text {
                            text: parent.text
                            color: window.activeViewIndex === 1 ? theme.accentInfo : theme.textMuted
                            font.family: theme.fontFamily
                            font.pixelSize: 10
                            font.bold: true
                        }
                        background: Rectangle {
                            color: window.activeViewIndex === 1 ? "#1E222A" : "transparent"
                            radius: 4
                            implicitWidth: 105
                            implicitHeight: 30
                        }
                    }

                    Button {
                        text: "DETAILS"
                        onClicked: window.activeViewIndex = 2
                        contentItem: Text {
                            text: parent.text
                            color: window.activeViewIndex === 2 ? theme.textPrimary : theme.textMuted
                            font.family: theme.fontFamily
                            font.pixelSize: 10
                            font.bold: true
                        }
                        background: Rectangle {
                            color: window.activeViewIndex === 2 ? "#1E222A" : "transparent"
                            radius: 4
                            implicitWidth: 75
                            implicitHeight: 30
                        }
                    }

                    Button {
                        text: window.visibility === Window.FullScreen ? "WINDOW" : "FULLSCREEN"
                        onClicked: {
                            if (window.visibility === Window.FullScreen) {
                                window.showNormal();
                            } else {
                                window.showFullScreen();
                            }
                        }
                        contentItem: Text {
                            text: parent.text
                            color: theme.textSecondary
                            font.family: theme.fontFamily
                            font.pixelSize: 10
                            font.bold: true
                        }
                        background: Rectangle {
                            color: "#161920"
                            border.color: theme.surfaceBorder
                            radius: 4
                            implicitWidth: 85
                            implicitHeight: 30
                        }
                    }
                }

                Item { width: 16 }

                // Master System ON / OFF Switch
                Row {
                    spacing: 10
                    Layout.alignment: Qt.AlignVCenter

                    Text {
                        text: bridge.systemOn ? "SYSTEM ON" : "SYSTEM OFF"
                        color: bridge.systemOn ? theme.accentActive : theme.textMuted
                        font.family: theme.fontFamily
                        font.pixelSize: 11
                        font.bold: true
                        anchors.verticalCenter: parent.verticalCenter
                    }

                    Switch {
                        id: systemSwitch
                        checked: bridge.systemOn
                        onClicked: bridge.toggleSystem()
                        anchors.verticalCenter: parent.verticalCenter
                    }
                }
            }
        }

        // ── Main Content Area ───────────────────────────────────────────────
        StackLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            currentIndex: window.activeViewIndex

            // View 0: Primary Live Monitor Screen
            Item {
                id: liveMonitorView
                Layout.fillWidth: true
                Layout.fillHeight: true

                RowLayout {
                    anchors.fill: parent
                    spacing: 16

                    // Left Side: Dominant Camera Feed (~70% width)
                    CameraView {
                        id: cameraView
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        Layout.minimumWidth: 500
                        Layout.minimumHeight: 380
                        systemOn: bridge.systemOn
                        frameCounter: bridge.frameCounter
                    }

                    // Right Side: Fixed-width Sidebar (~30% width)
                    Item {
                        id: sidebarWrapper
                        Layout.preferredWidth: 350
                        Layout.minimumWidth: 320
                        Layout.maximumWidth: 380
                        Layout.fillHeight: true

                        ColumnLayout {
                            anchors.fill: parent
                            spacing: 12

                            GestureBadge {
                                Layout.fillWidth: true
                                gestureName: bridge.productGestureName
                                confidence: bridge.confidence
                                stabilizerState: bridge.stabilizerState
                            }

                            SafetyIndicator {
                                Layout.fillWidth: true
                                isStopArmed: bridge.isStopArmed
                                safetyStatus: bridge.safetyStatus
                                onResetNeutralRequested: bridge.resetNeutral()
                            }

                            SerialStatus {
                                Layout.fillWidth: true
                                isConnected: bridge.serialConnected
                                lastCommand: bridge.lastEmittedCommand
                                wireFrame: bridge.wireFrameStr
                            }

                            TelemetryCard {
                                Layout.fillWidth: true
                                Layout.fillHeight: true
                                fps: bridge.fps
                                latencyMs: bridge.latencyMs
                                modelUsed: bridge.modelUsed
                                routingStr: bridge.routingStr
                                handCount: bridge.handCount
                            }
                        }
                    }
                }
            }

            // View 1: Product Gesture Guide
            GestureGuide {
                Layout.fillWidth: true
                Layout.fillHeight: true
            }

            // View 2: Technical Architecture Details
            DetailsView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                canonicalCommand: bridge.canonicalCommand
                confidence: bridge.confidence
                modelUsed: bridge.modelUsed
                routingStr: bridge.routingStr
                fps: bridge.fps
                latencyMs: bridge.latencyMs
            }
        }
    }
}
