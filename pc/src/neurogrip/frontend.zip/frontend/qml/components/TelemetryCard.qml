import QtQuick 2.15
import "../theme"

Rectangle {
    id: telemetryRoot
    color: theme.surfaceDark
    border.color: theme.surfaceBorder
    border.width: 1
    radius: 8
    implicitHeight: 180

    property real fps: 0.0
    property real latencyMs: 0.0
    property string modelUsed: "N/A"
    property string routingStr: "N/A"
    property string handCount: "0"

    Theme { id: theme }

    Column {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 12

        Text {
            text: "SYSTEM TELEMETRY"
            color: theme.textMuted
            font.family: theme.fontFamily
            font.pixelSize: theme.fontSizeCaption
            font.bold: true
            font.letterSpacing: 1.0
        }

        Grid {
            columns: 2
            rowSpacing: 10
            columnSpacing: 20
            width: parent.width

            // FPS
            Column {
                spacing: 2
                Text { text: "FRAME RATE"; color: theme.textMuted; font.pixelSize: 10; font.family: theme.fontFamily }
                Text { text: telemetryRoot.fps.toFixed(1) + " FPS"; color: theme.accentInfo; font.pixelSize: 14; font.bold: true; font.family: theme.fontFamily }
            }

            // Latency
            Column {
                spacing: 2
                Text { text: "LATENCY"; color: theme.textMuted; font.pixelSize: 10; font.family: theme.fontFamily }
                Text { text: telemetryRoot.latencyMs.toFixed(0) + " ms"; color: theme.accentInfo; font.pixelSize: 14; font.bold: true; font.family: theme.fontFamily }
            }

            // Engine
            Column {
                spacing: 2
                Text { text: "CLASSIFIER ENGINE"; color: theme.textMuted; font.pixelSize: 10; font.family: theme.fontFamily }
                Text { text: telemetryRoot.modelUsed; color: theme.textPrimary; font.pixelSize: 13; font.bold: true; font.family: theme.fontFamily }
            }

            // Hands Count
            Column {
                spacing: 2
                Text { text: "HAND COUNT"; color: theme.textMuted; font.pixelSize: 10; font.family: theme.fontFamily }
                Text { text: telemetryRoot.handCount; color: theme.textPrimary; font.pixelSize: 13; font.bold: true; font.family: theme.fontFamily }
            }
        }

        // Routing Indicator
        Column {
            width: parent.width
            spacing: 2

            Text { text: "ROUTE PATH"; color: theme.textMuted; font.pixelSize: 10; font.family: theme.fontFamily }
            Text {
                text: telemetryRoot.routingStr
                color: theme.textSecondary
                font.pixelSize: 11
                font.family: theme.fontFamily
                elide: Text.ElideRight
                width: parent.width
            }
        }
    }
}
