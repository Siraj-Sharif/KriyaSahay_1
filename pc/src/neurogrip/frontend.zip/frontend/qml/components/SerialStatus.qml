import QtQuick 2.15
import QtQuick.Layouts 1.15
import "../theme"

Rectangle {
    id: serialRoot
    color: theme.surfaceDark
    border.color: theme.surfaceBorder
    border.width: 1
    radius: 8
    implicitHeight: 90

    property bool isConnected: false
    property string lastCommand: "NONE"
    property string wireFrame: "NONE"

    Theme { id: theme }

    Column {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 8

        RowLayout {
            width: parent.width

            Text {
                text: "WIRE PROTOCOL TRANSMISSION"
                color: theme.textMuted
                font.family: theme.fontFamily
                font.pixelSize: 10
                font.bold: true
                font.letterSpacing: 1.0
            }

            Item { Layout.fillWidth: true }

            // Connection Badge
            Rectangle {
                height: 18
                width: connText.width + 12
                radius: 9
                color: serialRoot.isConnected ? Qt.rgba(0.06, 0.72, 0.51, 0.15) : Qt.rgba(0.93, 0.27, 0.27, 0.15)
                border.color: serialRoot.isConnected ? theme.accentActive : theme.accentStop

                Text {
                    id: connText
                    anchors.centerIn: parent
                    text: serialRoot.isConnected ? "CONNECTED" : "MOCK SERIAL"
                    color: serialRoot.isConnected ? theme.accentActive : theme.textSecondary
                    font.family: theme.fontFamily
                    font.pixelSize: 9
                    font.bold: true
                }
            }
        }

        // Live Wire Frame Display
        Rectangle {
            width: parent.width
            height: 32
            radius: 4
            color: "#0B0C10"
            border.color: "#1E222A"

            Row {
                anchors.centerIn: parent
                spacing: 8

                Text {
                    text: "TX:"
                    color: theme.textMuted
                    font.family: "Consolas, monospace"
                    font.pixelSize: 12
                    font.bold: true
                }

                Text {
                    text: serialRoot.wireFrame
                    color: theme.accentActive
                    font.family: "Consolas, monospace"
                    font.pixelSize: 13
                    font.bold: true
                }
            }
        }
    }
}
