import QtQuick 2.15
import QtQuick.Controls 2.15
import "../theme"

Rectangle {
    id: cameraRoot
    implicitWidth: 640
    implicitHeight: 480
    color: "#0B0C10"
    border.color: "#1E222A"
    border.width: 1
    radius: 10
    clip: true

    property bool systemOn: true
    property int frameCounter: 0

    Theme { id: theme }

    // Live Video Stream Image (Dominant View)
    Image {
        id: videoImage
        anchors.fill: parent
        anchors.margins: 4
        fillMode: Image.PreserveAspectFit
        smooth: true
        cache: false
        visible: cameraRoot.systemOn

        // Reload source whenever frameCounter increments
        source: cameraRoot.systemOn ? "image://neurogrip/live?" + cameraRoot.frameCounter : ""
    }

    // Top-Left Live Feed Badge Overlay
    Rectangle {
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.margins: 16
        height: 26
        width: liveRow.width + 20
        radius: 13
        color: Qt.rgba(0.06, 0.07, 0.09, 0.85)
        border.color: "#262930"
        border.width: 1
        visible: cameraRoot.systemOn

        Row {
            id: liveRow
            anchors.centerIn: parent
            spacing: 8

            // Pulsing Green Indicator Dot
            Rectangle {
                width: 8
                height: 8
                radius: 4
                color: theme.accentActive
                anchors.verticalCenter: parent.verticalCenter

                SequentialAnimation on opacity {
                    running: cameraRoot.systemOn
                    loops: Animation.Infinite
                    NumberAnimation { from: 1.0; to: 0.3; duration: 600 }
                    NumberAnimation { from: 0.3; to: 1.0; duration: 600 }
                }
            }

            Text {
                text: "LIVE FEED"
                color: theme.textPrimary
                font.family: theme.fontFamily
                font.pixelSize: 10
                font.bold: true
                font.letterSpacing: 1.0
                anchors.verticalCenter: parent.verticalCenter
            }
        }
    }

    // System OFF / Idle Overlay State
    Rectangle {
        anchors.fill: parent
        color: "#08090C"
        opacity: 0.95
        visible: !cameraRoot.systemOn

        Column {
            anchors.centerIn: parent
            spacing: 14

            Rectangle {
                width: 56
                height: 56
                radius: 28
                color: "#14171E"
                border.color: "#262930"
                border.width: 1
                anchors.horizontalCenter: parent.horizontalCenter

                Text {
                    text: "OFF"
                    color: theme.textMuted
                    font.family: theme.fontFamily
                    font.pixelSize: 13
                    font.bold: true
                    anchors.centerIn: parent
                }
            }

            Text {
                text: "SYSTEM STANDBY"
                color: theme.textSecondary
                font.family: theme.fontFamily
                font.pixelSize: 16
                font.bold: true
                font.letterSpacing: 1.5
                anchors.horizontalCenter: parent.horizontalCenter
            }

            Text {
                text: "Toggle System ON to activate real-time camera feed and CV pipeline"
                color: theme.textMuted
                font.family: theme.fontFamily
                font.pixelSize: 11
                anchors.horizontalCenter: parent.horizontalCenter
            }
        }
    }
}
