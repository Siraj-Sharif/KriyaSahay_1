import QtQuick 2.15

Item {
    id: particleRoot
    anchors.fill: parent

    // Pure Jet Black Base Environment
    Rectangle {
        anchors.fill: parent
        color: "#000000"
        z: -10
    }

    // Native High-Density Sprinkle Canvas Layer (Offloaded Canvas Rendering)
    Canvas {
        id: sprinkleCanvas
        anchors.fill: parent
        renderTarget: Canvas.Image
        renderStrategy: Canvas.Threaded

        property int particleCount: 1400
        property var particleData: []

        function generateParticles() {
            var data = [];
            var w = sprinkleCanvas.width > 0 ? sprinkleCanvas.width : 1600;
            var h = sprinkleCanvas.height > 0 ? sprinkleCanvas.height : 1000;

            for (var i = 0; i < particleCount; i++) {
                // Power curve distribution concentrating density towards bottom
                var yNorm = Math.pow(Math.random(), 0.38);
                var xNorm = Math.random();
                
                // Particle size: tiny crisp sprinkles (0.6px to 2.2px)
                var r = Math.random() < 0.85 ? (Math.random() * 0.8 + 0.6) : (Math.random() * 1.2 + 1.4);
                
                // Opacity with bottom-weighted intensity
                var baseAlpha = (Math.random() * 0.4 + 0.12) * (0.35 + 0.65 * yNorm);

                data.push({
                    xNorm: xNorm,
                    yNorm: yNorm,
                    r: r,
                    alpha: baseAlpha
                });
            }
            particleData = data;
        }

        Component.onCompleted: { generateParticles(); requestPaint(); }
        onWidthChanged: { generateParticles(); requestPaint(); }
        onHeightChanged: { generateParticles(); requestPaint(); }

        onPaint: {
            var ctx = sprinkleCanvas.getContext("2d");
            ctx.clearRect(0, 0, width, height);

            var w = width;
            var h = height;
            var len = particleData.length;

            for (var i = 0; i < len; i++) {
                var p = particleData[i];
                var px = p.xNorm * w;
                var py = p.yNorm * h;

                ctx.fillStyle = "rgba(255, 255, 255, " + p.alpha.toFixed(3) + ")";
                ctx.beginPath();
                ctx.arc(px, py, p.r, 0, 2 * Math.PI, false);
                ctx.fill();
            }
        }
    }

    // Dynamic Floating & Twinkling Sparkles (Subtle Overlay Elements)
    Repeater {
        model: 40

        Rectangle {
            id: sparkle
            width: Math.random() < 0.25 ? 3 : (Math.random() < 0.7 ? 2 : 1)
            height: width
            radius: width / 2
            color: "#FFFFFF"

            property real startY: Math.pow(Math.random(), 0.45) * (particleRoot.height > 0 ? particleRoot.height : 1000)
            property real startX: Math.random() * (particleRoot.width > 0 ? particleRoot.width : 1600)
            property int moveDuration: 14000 + Math.random() * 10000

            x: startX
            y: startY
            opacity: 0.15

            SequentialAnimation on y {
                running: true
                loops: Animation.Infinite
                NumberAnimation {
                    from: sparkle.startY
                    to: Math.max(0, sparkle.startY - 90)
                    duration: sparkle.moveDuration
                }
                NumberAnimation {
                    from: sparkle.startY
                    to: sparkle.startY
                    duration: 0
                }
            }

            SequentialAnimation on opacity {
                running: true
                loops: Animation.Infinite
                NumberAnimation { from: 0.08; to: 0.70; duration: 2400 + Math.random() * 2000; easing.type: Easing.InOutSine }
                NumberAnimation { from: 0.70; to: 0.08; duration: 2400 + Math.random() * 2000; easing.type: Easing.InOutSine }
            }
        }
    }
}
