import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import "../theme"

Rectangle {
    id: badgeRoot
    color: theme.surfaceDark
    border.color: theme.surfaceBorder
    border.width: 1
    radius: 8
    implicitHeight: 130

    property string gestureName: "NO HAND"
    property real confidence: 0.0
    property string stabilizerState: "UNKNOWN_STATE"

    Theme { id: theme }

    // Dynamic accent color computation based on gesture state
    function getAccentColor() {
        if (gestureName === "STOP") return theme.accentStop;
        if (gestureName === "NO HAND" || gestureName === "OFF") return theme.textMuted;
        if (gestureName === "NO COMMAND" || gestureName === "MULTIPLE HANDS") return theme.accentWarning;
        return theme.accentActive;
    }

    Column {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 8

        // Header Row: Status Label & Stability Pill
        RowLayout {
            width: parent.width

            Text {
                text: "CURRENT GESTURE"
                color: theme.textMuted
                font.family: theme.fontFamily
                font.pixelSize: theme.fontSizeCaption
                font.bold: true
                font.letterSpacing: 1.0
            }

            Item { Layout.fillWidth: true }

            Rectangle {
                height: 20
                width: stabText.width + 16
                radius: 10
                color: Qt.rgba(badgeRoot.getAccentColor().r, badgeRoot.getAccentColor().g, badgeRoot.getAccentColor().b, 0.15)
                border.color: badgeRoot.getAccentColor()
                border.width: 1

                Text {
                    id: stabText
                    anchors.centerIn: parent
                    text: badgeRoot.stabilizerState
                    color: badgeRoot.getAccentColor()
                    font.family: theme.fontFamily
                    font.pixelSize: 10
                    font.bold: true
                }
            }
        }

        // Gesture Name Display
        Text {
            text: badgeRoot.gestureName
            color: badgeRoot.getAccentColor()
            font.family: theme.fontFamily
            font.pixelSize: theme.fontSizeTitle
            font.bold: true
            elide: Text.ElideRight
            width: parent.width

            Behavior on color {
                ColorAnimation { duration: 250 }
            }
        }

        // Confidence Meter Row
        Row {
            width: parent.width
            spacing: 12

            Text {
                text: Math.round(badgeRoot.confidence * 100) + "% CONFIDENCE"
                color: theme.textSecondary
                font.family: theme.fontFamily
                font.pixelSize: theme.fontSizeCaption
                font.bold: true
                anchors.verticalCenter: parent.verticalCenter
            }

            Rectangle {
                height: 4
                width: parent.width - 120
                radius: 2
                color: "#262930"
                anchors.verticalCenter: parent.verticalCenter

                Rectangle {
                    height: parent.height
                    width: Math.min(parent.width, Math.max(0, parent.width * badgeRoot.confidence))
                    radius: 2
                    color: badgeRoot.getAccentColor()

                    Behavior on width {
                        NumberAnimation { duration: 150 }
                    }
                }
            }
        }
    }
}
