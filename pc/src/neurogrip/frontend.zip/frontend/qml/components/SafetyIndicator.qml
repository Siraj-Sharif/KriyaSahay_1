import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import "../theme"

Rectangle {
    id: safetyRoot
    color: theme.surfaceDark
    border.color: isStopArmed ? theme.accentActive : theme.surfaceBorder
    border.width: 1
    radius: 8
    implicitHeight: 80

    property bool isStopArmed: false
    property string safetyStatus: "DISARMED"
    signal resetNeutralRequested()

    Theme { id: theme }

    readonly property bool isStopActive: safetyStatus === "STOP ACTIVE"
    readonly property bool isArmed: isStopArmed || safetyStatus === "ARMED" || safetyStatus === "STOP ARMED"
    readonly property string displayStateText: isStopActive ? "STOP ACTIVE" : (isArmed ? "ARMED" : "DISARMED")
    readonly property color displayStateColor: isStopActive ? theme.accentStop : (isArmed ? theme.accentActive : theme.accentWarning)

    RowLayout {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 16

        // Warning / Status Light
        Rectangle {
            width: 16
            height: 16
            radius: 8
            color: safetyRoot.displayStateColor

            SequentialAnimation on opacity {
                running: safetyRoot.isStopArmed || safetyRoot.isStopActive
                loops: Animation.Infinite
                NumberAnimation { from: 1.0; to: 0.3; duration: 500 }
                NumberAnimation { from: 0.3; to: 1.0; duration: 500 }
            }
        }

        Column {
            spacing: 2

            Text {
                text: "STOP INTERLOCK"
                color: theme.textMuted
                font.family: theme.fontFamily
                font.pixelSize: 10
                font.bold: true
                font.letterSpacing: 1.0
            }

            Text {
                text: safetyRoot.displayStateText
                color: safetyRoot.displayStateColor
                font.family: theme.fontFamily
                font.pixelSize: theme.fontSizeSubheader
                font.bold: true
            }
        }

        Item { Layout.fillWidth: true }

        // Explicit Physical RESET / NEUTRAL Button
        Button {
            id: resetBtn
            text: "RESET / NEUTRAL"
            onClicked: safetyRoot.resetNeutralRequested()

            contentItem: Text {
                text: parent.text
                color: theme.textPrimary
                font.family: theme.fontFamily
                font.pixelSize: 10
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }

            background: Rectangle {
                implicitWidth: 115
                implicitHeight: 32
                radius: 4
                color: resetBtn.down ? "#1E222A" : "#262930"
                border.color: theme.surfaceBorder
            }
        }
    }
}

