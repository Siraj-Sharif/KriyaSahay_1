import QtQuick 2.15

QtObject {
    id: theme

    // Palette Tokens
    readonly property color bgDark: "#000000"
    readonly property color surfaceDark: "#0A0C10"
    readonly property color surfaceBorder: "#1C1F26"
    readonly property color textPrimary: "#E6E8EC"
    readonly property color textSecondary: "#9DA3AE"
    readonly property color textMuted: "#6B7280"
    
    // Status Accents
    readonly property color accentActive: "#10B981"   // Emerald Green
    readonly property color accentStop: "#EF4444"     // Crimson Red
    readonly property color accentWarning: "#F59E0B"  // Amber
    readonly property color accentInfo: "#06B6D4"     // Cyan

    // Typography
    readonly property string fontFamily: "Segoe UI, Inter, Roboto, sans-serif"
    readonly property int fontSizeHeader: 20
    readonly property int fontSizeSubheader: 14
    readonly property int fontSizeTitle: 28
    readonly property int fontSizeLarge: 42
    readonly property int fontSizeBody: 13
    readonly property int fontSizeCaption: 11
}
