"""
neurogrip/frontend/application.py
──────────────────────────────────
NeuroGrip PySide6 Qt Quick Application Orchestrator.
"""

import sys
from pathlib import Path
from typing import Optional

from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuickControls2 import QQuickStyle

from neurogrip.camera.base import CameraInterface
from neurogrip.communication.base import SerialInterface
from neurogrip.config.settings import AppConfig
from neurogrip.frontend.bridge import NeuroGripBridge
from neurogrip.frontend.image_provider import FrameImageProvider


def run_neurogrip_app(
    config: Optional[AppConfig] = None,
    camera: Optional[CameraInterface] = None,
    serial: Optional[SerialInterface] = None,
    argv: Optional[list[str]] = None,
) -> int:
    """
    Launch the official NeuroGrip PySide6 / QML Product Desktop Application.

    Returns
    -------
    int
        Application exit code.
    """
    args = argv if argv is not None else sys.argv
    app = QGuiApplication(args)
    app.setApplicationName("NeuroGrip")
    app.setOrganizationName("NeuroGrip AI")

    QQuickStyle.setStyle("Basic")
    engine = QQmlApplicationEngine()

    # Register Thread-Safe Live Image Provider
    image_provider = FrameImageProvider()
    engine.addImageProvider("neurogrip", image_provider)

    # Instantiate Bridge & Connect to QML Context
    bridge = NeuroGripBridge(
        image_provider=image_provider,
        config=config,
        camera=camera,
        serial=serial,
    )
    engine.rootContext().setContextProperty("bridge", bridge)

    # Load Main.qml
    qml_path = Path(__file__).parent / "qml" / "Main.qml"
    engine.load(str(qml_path))

    if not engine.rootObjects():
        print("ERROR: Failed to load QML root object.")
        return -1

    # Start Pipeline Loop
    bridge.start_pipeline()

    # Execute Qt event loop
    ret = app.exec()

    # Clean shutdown
    bridge.stop_pipeline()
    return ret
