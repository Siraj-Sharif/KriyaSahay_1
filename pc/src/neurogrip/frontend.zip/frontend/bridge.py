"""
neurogrip/frontend/bridge.py
─────────────────────────────
PySide6 QObject Bridge connecting the frozen NeuroGrip Pipeline to Qt Quick / QML.

Follows standard Qt Worker Architecture:
  QThread (event loop host)
     ↓
  PipelineWorker (QObject worker)
     ↓
  NeuroGripPipeline (Frozen Core Orchestrator)

Translates internal canonical gesture commands to official product display names:
  CALL         -> CALL
  CLOSED_FIST  -> FIST
  FOUR_FINGERS -> FOUR
  GRABBING     -> GRAB
  GRIP         -> GRIP
  THUMBS_UP    -> THUMBS UP
  PINKY        -> PINKY
  MIDDLE_FINGER-> MIDDLE
  OK           -> OK
  INDEX_FINGER -> POINT
  INDEX_PINKY  -> INDEX + PINKY
  STOP         -> STOP
  TWO_FINGERS  -> TWO
  THREE_FINGERS-> THREE
  NO_HAND      -> NO HAND
  AMBIGUOUS    -> MULTIPLE HANDS
  NO_COMMAND   -> NO COMMAND
"""

import logging
import time
from typing import Optional
import cv2
from PySide6.QtCore import QObject, QThread, Signal, Slot, Property
from PySide6.QtGui import QImage

from neurogrip.app.pipeline import NeuroGripPipeline
from neurogrip.camera.base import CameraInterface
from neurogrip.communication.base import SerialInterface
from neurogrip.config.settings import AppConfig
from neurogrip.frontend.image_provider import FrameImageProvider
from neurogrip.visualization.base import VisualizationState

logger = logging.getLogger(__name__)


PRODUCT_GESTURE_MAP: dict[str, str] = {
    "CALL": "CALL",
    "CLOSED_FIST": "FIST",
    "FOUR_FINGERS": "FOUR",
    "GRABBING": "GRAB",
    "GRIP": "GRIP",
    "THUMBS_UP": "THUMBS UP",
    "PINKY": "PINKY",
    "MIDDLE_FINGER": "MIDDLE",
    "OK": "OK",
    "INDEX_FINGER": "POINT",
    "INDEX_PINKY": "INDEX + PINKY",
    "STOP": "STOP",
    "TWO_FINGERS": "TWO",
    "THREE_FINGERS": "THREE",
    "NO_HAND": "NO HAND",
    "AMBIGUOUS": "MULTIPLE HANDS",
    "NO_COMMAND": "NO COMMAND",
    "UNKNOWN": "NO COMMAND",
    "NONE": "NO COMMAND",
}


def map_canonical_to_product_display(canonical_name: str) -> str:
    """Map canonical backend command string to product display name."""
    if not canonical_name:
        return "NO COMMAND"
    return PRODUCT_GESTURE_MAP.get(canonical_name.upper(), canonical_name.upper())


class PipelineWorker(QObject):
    """
    Standard Qt QObject Worker driving the NeuroGripPipeline in a separate thread.
    Moved to a QThread via `moveToThread()`.
    """

    frame_processed = Signal(object, object)  # (qimage_or_bgr, viz_state)
    finished = Signal()

    def __init__(self, pipeline: NeuroGripPipeline) -> None:
        super().__init__()
        self.pipeline = pipeline
        self._running = False

    @Slot()
    def process_loop(self) -> None:
        """Core loop running inside the worker QThread."""
        self._running = True
        logger.info("PipelineWorker loop started in worker thread.")

        while self._running:
            try:
                if not self.pipeline.is_initialized:
                    if not self.pipeline.initialize():
                        time.sleep(0.1)
                        continue

                frame_container, rendered_frame, viz_state = self.pipeline.process_frame()
                frame_bgr = rendered_frame if rendered_frame is not None else frame_container.frame
                
                # Pre-convert frame to QImage in worker thread to offload GUI main thread
                qimg = None
                if frame_bgr is not None and frame_bgr.size > 0:
                    try:
                        h, w, ch = frame_bgr.shape
                        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
                        bytes_per_line = ch * w
                        qimg = QImage(frame_rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888).copy()
                    except Exception:
                        qimg = frame_bgr

                self.frame_processed.emit(qimg, viz_state)
            except Exception as e:
                logger.error("Error in PipelineWorker loop: %s", e)
                time.sleep(0.05)
            
            # Restrained loop sleep (~30 FPS target)
            time.sleep(0.02)

        # Offloaded clean pipeline shutdown inside worker thread upon loop exit
        try:
            self.pipeline.shutdown()
        except Exception as e:
            logger.error("Error shutting down pipeline in worker thread: %s", e)

        self.finished.emit()
        logger.info("PipelineWorker loop finished.")

    def stop(self) -> None:
        """Signal the worker loop to stop."""
        self._running = False


class NeuroGripBridge(QObject):
    """
    QObject Bridge class exposing pipeline state and telemetry to QML via Q_PROPERTYs and Q_SLOTs.
    """

    # Signals for property updates
    systemOnChanged = Signal(bool)
    productGestureNameChanged = Signal(str)
    canonicalCommandChanged = Signal(str)
    confidenceChanged = Signal(float)
    stabilizerStateChanged = Signal(str)
    handCountChanged = Signal(str)
    fpsChanged = Signal(float)
    latencyMsChanged = Signal(float)
    modelUsedChanged = Signal(str)
    routingStrChanged = Signal(str)
    safetyStatusChanged = Signal(str)
    isStopArmedChanged = Signal(bool)
    serialConnectedChanged = Signal(bool)
    lastEmittedCommandChanged = Signal(str)
    wireFrameStrChanged = Signal(str)
    frameCounterChanged = Signal(int)

    def __init__(
        self,
        image_provider: FrameImageProvider,
        config: Optional[AppConfig] = None,
        camera: Optional[CameraInterface] = None,
        serial: Optional[SerialInterface] = None,
    ) -> None:
        super().__init__()
        self.image_provider = image_provider
        self.config = config or AppConfig.default()
        
        # Instantiate frozen backend pipeline
        self.pipeline = NeuroGripPipeline(config=self.config, camera=camera, serial=serial)

        # Worker Thread Setup
        self._thread: Optional[QThread] = None
        self._worker: Optional[PipelineWorker] = None

        # Reactive State Variables
        self._system_on: bool = False
        self._product_gesture_name: str = "NO HAND"
        self._canonical_command: str = "NO_COMMAND"
        self._confidence: float = 0.0
        self._stabilizer_state: str = "UNKNOWN_STATE"
        self._hand_count: str = "0"
        self._fps: float = 0.0
        self._latency_ms: float = 0.0
        self._model_used: str = "N/A"
        self._routing_str: str = "N/A"
        self._safety_status: str = "DISARMED"
        self._is_stop_armed: bool = False
        self._serial_connected: bool = False
        self._last_emitted_command: str = "NONE"
        self._wire_frame_str: str = "NONE"
        self._frame_counter: int = 0

    def start_pipeline(self) -> None:
        """Start the worker QThread and pipeline loop."""
        if self._thread is not None and self._thread.isRunning():
            return

        self._thread = QThread()
        self._worker = PipelineWorker(self.pipeline)
        self._worker.moveToThread(self._thread)

        # Keep reference to prevent early Python GC before thread finishes
        if not hasattr(self, "_active_threads"):
            self._active_threads = []
        self._active_threads.append(self._thread)

        thread_ref = self._thread
        def _cleanup():
            if thread_ref in self._active_threads:
                self._active_threads.remove(thread_ref)

        # Connect signals
        self._thread.started.connect(self._worker.process_loop)
        self._worker.frame_processed.connect(self._on_frame_processed)
        self._worker.finished.connect(self._thread.quit)
        self._thread.finished.connect(_cleanup)
        self._thread.finished.connect(self._thread.deleteLater)

        self._system_on = True
        self.systemOnChanged.emit(True)
        self._thread.start()

    def stop_pipeline(self, wait: bool = False) -> None:
        """Asynchronously signal worker loop to stop without blocking GUI thread."""
        if not self._system_on:
            return

        self._system_on = False
        self.systemOnChanged.emit(False)

        if self._worker is not None:
            self._worker.stop()

        if wait and self._thread is not None and self._thread.isRunning():
            self._thread.quit()
            self._thread.wait(2000)

        self._thread = None
        self._worker = None

        # Reset telemetry to safe idle state immediately
        self._set_product_gesture_name("OFF")
        self._set_canonical_command("NO_COMMAND")
        self._set_confidence(0.0)
        self._set_stabilizer_state("IDLE")
        self._set_hand_count("0")
        self._set_fps(0.0)
        self._set_latency_ms(0.0)

    # ── Slot Implementations ──────────────────────────────────────────────────

    @Slot()
    def toggleSystem(self) -> None:
        """Toggle master System ON / OFF state."""
        if self._system_on:
            self.stop_pipeline()
        else:
            self.start_pipeline()

    @Slot()
    def toggleStopArm(self) -> None:
        """Toggle software STOP safety arming state (Internal helper/backend testing)."""
        new_state = self.pipeline.toggle_stop_arm()
        self._is_stop_armed = new_state
        self.isStopArmedChanged.emit(new_state)
        self._set_safety_status("ARMED" if new_state else "DISARMED")

    @Slot()
    def resetNeutral(self) -> None:
        """Send explicit physical NEUTRAL reset command over serial if system is ON."""
        if not self._system_on:
            logger.warning("resetNeutral requested while SYSTEM is OFF; ignored.")
            return

        # Transmit explicit NEUTRAL wire frame over serial interface
        if hasattr(self.pipeline, "serial") and self.pipeline.serial:
            try:
                tx_ok = self.pipeline.serial.send_command("NEUTRAL")
                if tx_ok:
                    self._set_last_emitted_command("NEUTRAL")
                    self._set_wire_frame_str("NG1|NEUTRAL\n")
                    logger.info("[RESET / NEUTRAL] Transmitted explicit physical reset frame: NG1|NEUTRAL\\n")
            except Exception as e:
                logger.error("Error sending NEUTRAL command: %s", e)


    # ── Frame Callback & Telemetry Update ─────────────────────────────────────

    def _on_frame_processed(self, qimg_or_bgr: Optional[object], viz_state: VisualizationState) -> None:
        """Process incoming frame and update QML reactive properties."""
        if not self._system_on:
            return

        # Update QML Image Provider
        if qimg_or_bgr is not None:
            if hasattr(qimg_or_bgr, "isNull"):
                self.image_provider.update_qimage(qimg_or_bgr)
            else:
                self.image_provider.update_frame(qimg_or_bgr)
            self._frame_counter += 1
            self.frameCounterChanged.emit(self._frame_counter)

        if viz_state is None:
            return

        # Map canonical command to product display name
        cmd = viz_state.command
        display_name = map_canonical_to_product_display(cmd)

        self._set_product_gesture_name(display_name)
        self._set_canonical_command(cmd)
        self._set_confidence(viz_state.confidence)
        self._set_stabilizer_state(viz_state.stabilizer_state)
        self._set_hand_count(viz_state.hand_count)
        self._set_fps(viz_state.fps)
        self._set_latency_ms(viz_state.latency_ms)
        self._set_model_used(viz_state.model_used)
        self._set_routing_str(viz_state.routing_str)
        safety_str = viz_state.safety_status
        if safety_str == "STOP ARMED":
            safety_str = "ARMED"
        elif safety_str == "STOP DISARMED":
            safety_str = "DISARMED"
        self._set_safety_status(safety_str)

        # Serial status
        serial_conn = self.pipeline.serial.is_connected if self.pipeline.serial else False
        if serial_conn != self._serial_connected:
            self._serial_connected = serial_conn
            self.serialConnectedChanged.emit(serial_conn)

        last_tx = self.pipeline.stabilizer.last_emitted_command if self.pipeline.stabilizer else None
        if last_tx and last_tx != "NO_COMMAND":
            self._set_last_emitted_command(last_tx)
            self._set_wire_frame_str(f"NG1|{last_tx}\\n")

    # ── Property Setters ──────────────────────────────────────────────────────

    def _set_product_gesture_name(self, val: str) -> None:
        if self._product_gesture_name != val:
            self._product_gesture_name = val
            self.productGestureNameChanged.emit(val)

    def _set_canonical_command(self, val: str) -> None:
        if self._canonical_command != val:
            self._canonical_command = val
            self.canonicalCommandChanged.emit(val)

    def _set_confidence(self, val: float) -> None:
        if abs(self._confidence - val) > 0.001:
            self._confidence = val
            self.confidenceChanged.emit(val)

    def _set_stabilizer_state(self, val: str) -> None:
        if self._stabilizer_state != val:
            self._stabilizer_state = val
            self.stabilizerStateChanged.emit(val)

    def _set_hand_count(self, val: str) -> None:
        if self._hand_count != val:
            self._hand_count = val
            self.handCountChanged.emit(val)

    def _set_fps(self, val: float) -> None:
        if abs(self._fps - val) > 0.1:
            self._fps = val
            self.fpsChanged.emit(val)

    def _set_latency_ms(self, val: float) -> None:
        if abs(self._latency_ms - val) > 0.5:
            self._latency_ms = val
            self.latencyMsChanged.emit(val)

    def _set_model_used(self, val: str) -> None:
        if self._model_used != val:
            self._model_used = val
            self.modelUsedChanged.emit(val)

    def _set_routing_str(self, val: str) -> None:
        if self._routing_str != val:
            self._routing_str = val
            self.routingStrChanged.emit(val)

    def _set_safety_status(self, val: str) -> None:
        if self._safety_status != val:
            self._safety_status = val
            self.safetyStatusChanged.emit(val)

    def _set_last_emitted_command(self, val: str) -> None:
        if self._last_emitted_command != val:
            self._last_emitted_command = val
            self.lastEmittedCommandChanged.emit(val)

    def _set_wire_frame_str(self, val: str) -> None:
        if self._wire_frame_str != val:
            self._wire_frame_str = val
            self.wireFrameStrChanged.emit(val)

    # ── Q_PROPERTY Getters ────────────────────────────────────────────────────

    @Property(bool, notify=systemOnChanged)
    def systemOn(self) -> bool:
        return self._system_on

    @Property(str, notify=productGestureNameChanged)
    def productGestureName(self) -> str:
        return self._product_gesture_name

    @Property(str, notify=canonicalCommandChanged)
    def canonicalCommand(self) -> str:
        return self._canonical_command

    @Property(float, notify=confidenceChanged)
    def confidence(self) -> float:
        return self._confidence

    @Property(str, notify=stabilizerStateChanged)
    def stabilizerState(self) -> str:
        return self._stabilizer_state

    @Property(str, notify=handCountChanged)
    def handCount(self) -> str:
        return self._hand_count

    @Property(float, notify=fpsChanged)
    def fps(self) -> float:
        return self._fps

    @Property(float, notify=latencyMsChanged)
    def latencyMs(self) -> float:
        return self._latency_ms

    @Property(str, notify=modelUsedChanged)
    def modelUsed(self) -> str:
        return self._model_used

    @Property(str, notify=routingStrChanged)
    def routingStr(self) -> str:
        return self._routing_str

    @Property(str, notify=safetyStatusChanged)
    def safetyStatus(self) -> str:
        return self._safety_status

    @Property(bool, notify=isStopArmedChanged)
    def isStopArmed(self) -> bool:
        return self._is_stop_armed

    @Property(bool, notify=serialConnectedChanged)
    def serialConnected(self) -> bool:
        return self._serial_connected

    @Property(str, notify=lastEmittedCommandChanged)
    def lastEmittedCommand(self) -> str:
        return self._last_emitted_command

    @Property(str, notify=wireFrameStrChanged)
    def wireFrameStr(self) -> str:
        return self._wire_frame_str

    @Property(int, notify=frameCounterChanged)
    def frameCounter(self) -> int:
        return self._frame_counter
