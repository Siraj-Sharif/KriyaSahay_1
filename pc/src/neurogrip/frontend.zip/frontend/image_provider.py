"""
neurogrip/frontend/image_provider.py
────────────────────────────────────
Thread-safe QQuickImageProvider bridge for streaming OpenCV video frames to Qt Quick / QML.
"""

import threading
from typing import Optional

import cv2
import numpy as np
from PySide6.QtGui import QImage
from PySide6.QtQuick import QQuickImageProvider


class FrameImageProvider(QQuickImageProvider):
    """
    Image provider for live OpenCV camera frames in QML.
    
    Serves frames requested via the QML URL schema: `image://neurogrip/live`
    """

    def __init__(self) -> None:
        super().__init__(QQuickImageProvider.ImageType.Image)
        self._lock = threading.Lock()
        self._current_qimage: Optional[QImage] = None
        # Placeholder blank black frame (640x480)
        self._blank_image = QImage(640, 480, QImage.Format.Format_RGB888)
        self._blank_image.fill(0)

    def update_qimage(self, qimg: Optional[QImage]) -> None:
        """
        Store pre-converted QImage reference from worker thread (O(1) fast path).
        """
        if qimg is None or qimg.isNull():
            return
        with self._lock:
            self._current_qimage = qimg

    def update_frame(self, frame_bgr: Optional[np.ndarray]) -> None:
        """
        Update current frame from an OpenCV BGR numpy array.
        
        Args:
            frame_bgr: BGR uint8 numpy array frame from camera/renderer, or None.
        """
        if frame_bgr is None or frame_bgr.size == 0:
            return

        try:
            h, w, ch = frame_bgr.shape
            frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            bytes_per_line = ch * w
            qimg = QImage(frame_rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888).copy()
            
            with self._lock:
                self._current_qimage = qimg
        except Exception:
            pass

    def requestImage(self, id: str, size: Optional[object], requestedSize: Optional[object]) -> QImage:
        """
        QQuickImageProvider virtual method implementation.
        
        Returns the latest QImage to QML.
        """
        with self._lock:
            if self._current_qimage is not None and not self._current_qimage.isNull():
                img = self._current_qimage
            else:
                img = self._blank_image

        if size is not None and hasattr(size, "setWidth") and hasattr(size, "setHeight"):
            size.setWidth(img.width())
            size.setHeight(img.height())
        return img
